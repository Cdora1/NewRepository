package arrays;

public class TT1  implements Cloneable{

	public static void main(String args[]) {

		int arr[] = { 1, 2, 3, 4, 5, 6, 7, 8 };
		int k = 3;

		int n = arr.length;

		for (int i = 0; i < n; i += k) {
			int left = i;

			// to handle case when k is not multiple
			// of n
			int right = Math.min(i + k - 1, n - 1);
			int temp;

			// reverse the sub-array [left, right]
			while (left < right) {
				temp = arr[left];
				arr[left] = arr[right];
				arr[right] = temp;
				left += 1;
				right -= 1;
			}
		}

		for (int i : arr)
			System.out.println(i + " ");
	}

	static void swap(int arr[], int start, int end) {
		int temp = 0;
		while (start < end) {
			temp = arr[start];
			arr[start] = arr[end];
			arr[end] = temp;
			start++;
			end--;
		}
	}
}
