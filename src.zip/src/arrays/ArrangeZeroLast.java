package arrays;

public class ArrangeZeroLast {

	public static void main(String[] args) {

		int arr[] = {1, 0, 0, 4, 0,0, 0, 5, 0};
		
		int index = 0;
		int temp = 0;
		int size = arr.length-1;
		for(int i=0; i<arr.length - index; i++){
			
			if(arr[i] == 0){
				if(arr[size-index] == 0){
					index = index +1;
					temp = arr[i];
					arr[i] = arr[size-index];
					arr[size-index] = temp;
				} else{
					temp = arr[i];
					arr[i] = arr[size-index];
					arr[size-index] = temp;
					index = index + 1;
				}
			}
		}
		
		for(int k : arr){
			System.out.println(k);
		}
	}

}
