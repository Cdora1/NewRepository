package arrays;

import javademo.ImmutableClass;

public class TT2 {

	public static void main(String[] args) {

		int arr[] = { 2, 7, 9, 5, 8, 7, 4 }, k = 5, j = 0;

		int temp = 0;
		for (int i = 0; i < arr.length; ++i) {

			if (arr[i] <= k ) {
				temp = arr[j];
				arr[j] = arr[i];
				arr[i] = temp;
			}
		}

		for (int i : arr)
			System.out.print(i + " ");

		System.out.println(j);
		
	}
	
	

}
