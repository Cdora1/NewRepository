package arrays;

import java.util.Arrays;
import java.util.Collections;

public class Find3LargestElements {

	public static void main(String[] args) {

		Integer arr[] = {1,4,2,3,6,8,5};
		Arrays.sort(arr, Collections.reverseOrder());
		
		for(int i=0; i<3; i++)
			System.out.print(arr[i] + " ");
	}

}
