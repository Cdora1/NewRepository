package arrays;

public class ZeroEnd {

	
	public static void main(String args[]){
		
		int arr[] = {1,3,5,6,0,1,0};
		int count =0;
		
		//ist non zero numbers
		for(int i=0; i<arr.length; i++)
			if(arr[i] != 0)
				arr[count++] = arr[i];
		
		//2nd add zero's
		while(count< arr.length){
			arr[count++] = 0;
		}
			
		
		for(int i : arr)
			System.out.println(i);
	}
}
