package dp;

public class IsSubsequence {

	public static void main(String[] args) {

		String s = "abc";
		String t = "ahbgdc";
		System.out.println(isSubsequence(s, t));
	}

	static boolean isSubsequence(String s, String t) {
		int i = 0;
		for (int j = 0; i < s.length() && j < t.length(); j++) {
			if (s.charAt(i) == t.charAt(j))
				++i;
		}
		return i == s.length();
	}
	static boolean isSubsequence1(String s, String t) {
        int fromIndex = 0;
        for (char c : s.toCharArray()) {
            fromIndex = t.indexOf(c, fromIndex);
            if (fromIndex++ < 0) {
                return false;
            }
        }
        return true;
    }
	
	static boolean isSubsequenceRec(String s, String t) {
	    return helper(s, t, 0, 0);
	}

	static boolean helper(String s, String t, int s_start, int t_start){
	    if(s_start == s.length()){
	        return true;
	    }else if(t_start == t.length()){
	        return false;
	    }
	    while(s.charAt(s_start) != t.charAt(t_start++)){
	        if(t_start == t.length()){
	            return false;
	        }
	    }
	    return helper(s, t, s_start + 1, t_start);
	}
}
