package dp;

public class SubSetSumCount {

	public static void main(String[] args) {
		int arr1[] = { 2, 3, 5, 6, 8, 10 };
		int sum1 = 10;
		System.out.println("subset_count dp : " + subset_count_dp(arr1, sum1, arr1.length)); // subset_count dp : 3
	}

	static int subset_count(int arr[], int sum, int n) {
		if (sum == 0)
			return 1;
		if (n == 0)
			return 0;
		else {
			if (arr[n - 1] > sum)
				return subset_count(arr, sum, n - 1);
			else {
				return subset_count(arr, sum, n - 1) + subset_count(arr, sum - arr[n - 1], n - 1);
			}
		}
	}

	static int count[][] = new int[7][11];

	static int subset_count_dp(int arr[], int sum, int n) {
		if (sum == 0)
			return 1;
		if (n == 0)
			return 0;
		if (count[n][sum] != 0)
			return count[n][sum];

		else {
			if (arr[n - 1] > sum)
				return subset_count_dp(arr, sum, n - 1);
			else {
				return count[n][sum] = subset_count_dp(arr, sum, n - 1) + subset_count_dp(arr, sum - arr[n - 1], n - 1);
			}
		}
	}
}
