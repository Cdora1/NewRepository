package dp;

/* Dynamic Programming Java implementation of Coin
Change problem */
import java.util.Arrays;

// Time & Space complexity of this function: O(mn) & O(n)
class CoinChangeWays {
	static long countWays(int S[], int m, int n) {

		// table[i] will be storing the number of solutions
		long[] table = new long[n + 1];
		Arrays.fill(table, 0); // O(n)

		// Base case (If given value is 0)
		table[0] = 1;

		// Pick all coins one by one and update the table[]
		// values after the index greater than or equal to
		// the value of the picked coin
		for (int i = 0; i < m; i++)
			for (int j = S[i]; j <= n; j++)
				table[j] += table[j - S[i]];

		return table[n];
	}

	public static void main(String args[]) {
		int coins[] = { 1, 2, 3 };
		int m = coins.length;
		int amount = 4;
		System.out.println(countWays(coins, m, amount));
		System.out.println("Rec " + coinChangeRec(coins, 0, amount));

		int dp[][] = new int[m + 1][amount + 1];
		for (int d[] : dp)
			Arrays.fill(d, -1);

		System.out.println("DP " + coinChangeDP(coins, 0, amount, dp));

		System.out.println("TopDown  " + change(amount, coins));

	}

	static int coinChangeDP(int coins[], int i, int amount, int dp[][]) {

		if (amount == 0)
			return 1;

		if (amount < 0 || i == coins.length)
			return 0;

		if (dp[i][amount] != -1)
			return dp[i][amount];

		return dp[i][amount] = coinChangeDP(coins, i, amount - coins[i], dp) + coinChangeDP(coins, i + 1, amount, dp);
	}

	static int coinChangeRec(int coins[], int i, int amount) {

		if (amount == 0)
			return 1;
		if (amount < 0 || i == coins.length)
			return 0;

		return coinChangeRec(coins, i, amount - coins[i]) + coinChangeRec(coins, i + 1, amount);
	}

	static int coinChangeButtomUp(int W, int[] coins, int n) {
		int i, j;
		int t[][] = new int[n + 1][W + 1];

		for (i = 0; i <= n; i++) {
			for (j = 0; j <= W; j++) {
				if (i == 0 && j == 0)
					t[i][j] = 0;
				if (i == 0 && j != 0)
					t[i][j] = 0;
				if (i >= 1 && j == 0)
					t[i][j] = 1;
			}
		}

		for (i = 1; i <= n; i++) {
			for (j = 1; j <= W; j++) {
				if (coins[i - 1] < j)
					t[i][j] = Math.max(t[i][j - coins[i - 1]], t[i - 1][j]);
				else
					t[i][j] = t[i - 1][j];
			}
		}
		return t[n][W];
	}

	static int change(int amount, int[] coins) {
		int arr[] = new int[amount + 1];
		Arrays.fill(arr, 0);
		arr[0] = 1;
		for (int c : coins)
			for (int i = c; i <= amount; i++)
				arr[i] += arr[i - c];
		return arr[amount];
	}

}
