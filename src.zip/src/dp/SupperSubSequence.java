package dp;

import java.util.Arrays;

public class SupperSubSequence {

	// Soln: formula - str1.length + str2.length -LCS. return this length.
	public static void main(String[] args) {

		String str1 = "geek", str2 = "eke";
		int n = str1.length(), m = str2.length();
		char x[] = str1.toCharArray();
		char y[] = str2.toCharArray();

		int dp[][] = new int[n + 1][m + 1];

		for (int d[] : dp)
			Arrays.fill(d, -1);

		//System.out.println(" LCS " + lcs(x, y, n, m, dp));

		int supperSequence = n + m - lcs(x, y, n, m, dp);
		System.out.println("Supper Sub Sequece lenght " + supperSequence);
	}

	static int lcs(char x[], char y[], int n, int m, int dp[][]) {

		if (n == 0 || m == 0)
			return 0;

		if (dp[n][m] != -1)
			return dp[m][n];

		if (x[n - 1] == y[m - 1])
			return dp[n][m] = lcs(x, y, n - 1, m - 1, dp) + 1;
		else
			return dp[n][m] = Math.max(lcs(x, y, n - 1, m, dp), lcs(x, y, n, m - 1, dp));
	}

}
