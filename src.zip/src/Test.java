public class Test {

	public static void main(String[] args) {

		int nums[] = {5,1,2,0,2,2,3};
		System.out.println(increasingTriplet(nums));
	}
	
	static boolean increasingTriplet(int[] nums) {
        int min = Integer.MAX_VALUE;
        int max = Integer.MAX_VALUE;
        
        for (int i = 0; i < nums.length; i++) {
            if (nums[i] > max) 
                return true;
            if (nums[i] <= min) 
                min = nums[i];
            else 
                max = nums[i];            
        }
        return false; 
    }

}
