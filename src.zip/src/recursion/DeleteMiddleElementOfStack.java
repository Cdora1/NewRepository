package recursion;

import java.util.Stack;

public class DeleteMiddleElementOfStack {

	public static void main(String[] args) {

		Stack<Integer> st = new Stack<Integer>();
		st.add(1);
		st.add(2);
		st.add(3);
		st.add(4);
		st.add(5);
		st.add(6);

		int middle = (st.size() / 2) + 1;
		deleteMiddleElement(st, middle);
		for (int in : st)
			System.out.print(in + " ");
	}

	static Stack<Integer> deleteMiddleElement(Stack<Integer> st, int mid) {
		if (st.size() == 0)
			return st;

		solve(st, mid);
		return st;
	}

	static void solve(Stack<Integer> st, int mid) {

		if (mid == 1) {
			st.pop();
			return;
		}

		int temp = st.peek();
		st.pop();
		solve(st, mid - 1);
		st.push(temp);
		return;
	}

}
