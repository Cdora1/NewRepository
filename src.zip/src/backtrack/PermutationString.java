package backtrack;

import java.util.Stack;

public class PermutationString {

	public static void main(String[] args) {

		String s1 = "ab", s2 = "eidbaooo";
		System.out.println();
		PermutationString obj = new PermutationString();
		System.out.println(obj.checkInclusion(s1, s2));
		
		String s = "()())()";
		System.out.println(isValid(s));
		System.out.println(obj.isValid1(s));
	}

	public boolean checkInclusion(String s1, String s2) {
		if (s1.length() > s2.length())
			return false;
		int[] s1map = new int[26];
		int[] s2map = new int[26];
		for (int i = 0; i < s1.length(); i++) {
			s1map[s1.charAt(i) - 'a']++;
			s2map[s2.charAt(i) - 'a']++;
		}
		for (int i = 0; i < s2.length() - s1.length(); i++) {
			if (matches(s1map, s2map))
				return true;
			s2map[s2.charAt(i + s1.length()) - 'a']++;
			s2map[s2.charAt(i) - 'a']--;
		}
		return matches(s1map, s2map);
	}

	public boolean matches(int[] s1map, int[] s2map) {
		for (int i = 0; i < 26; i++) {
			if (s1map[i] != s2map[i])
				return false;
		}
		return true;
	}

	static boolean isValid(String s) {
		int count = 0;

		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			
			if (c == '(')
				count++;
			
			if (c == ')' && count-- == 0)
				return false;
		}

		return count == 0;
	}
	
	public boolean isValid1(String s) {
	    Stack<Character> stack = new Stack<Character>();
		for (char c : s.toCharArray()) {
			if (c == '(')
				stack.push(')');
			else if (c == '{')
				stack.push('}');
			else if (c == '[')
				stack.push(']');
			else if (stack.isEmpty() || stack.pop() != c)
				return false;
		}
		return stack.isEmpty();
	}

}
