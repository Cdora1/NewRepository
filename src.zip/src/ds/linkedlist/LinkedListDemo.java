package ds.linkedlist;

public class LinkedListDemo {

	Node head;

	public static void main(String[] args) {

		LinkedListDemo lld = new LinkedListDemo();
		lld.head = new Node(5);
		lld.head.next = new Node(7);
		lld.insertFirst(3);
		lld.insertLast(lld.head, 9);
		lld.position(lld.head, 7);
		
		LinkedListDemo lld2 = new LinkedListDemo();
		lld2.head = new Node(10);
		lld2.head.next = new Node(15);
		 
		lld2.merge(lld, lld2);
		lld.print(lld.head);
	}

	void merge(LinkedListDemo lld, LinkedListDemo lld2){
		
		Node head = lld2.head;
		while(head != null){
			lld.insertLast(lld.head, head.item);
			head = head.next;
		}
	}
	void position(Node head, int data) {
		while (head != null) {
			if (head.item == data) {
				Node node = new Node(8);
				node.next = head.next;
				head.next = node;
				break;
			}
			head = head.next;
		}
	}

	void insertFirst(int data) {
		Node newNode = new Node(data);
		newNode.next = head;
		head = newNode;
	}

	void insertLast(Node head, int data) {
		while (head != null) {
			if (head.next == null) {
				head.next = new Node(data);
				break;
			}
			head = head.next;
		}
	}

	void print(Node head) {
		while (head != null) {
			System.out.println("Data" + head.item);
			head = head.next;
		}
	}
}

class Node {

	int item;
	Node next;

	Node(int data) {
		item = data;
		next = null;
	}
}