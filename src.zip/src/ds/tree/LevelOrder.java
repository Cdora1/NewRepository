package ds.tree;

import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Stack;

public class LevelOrder {

	public static void main(String[] args) {
		TreeNode root = new TreeNode(1);
		root.left = new TreeNode(2);
		root.right = new TreeNode(3);
		root.left.left = new TreeNode(4);
		root.left.right = new TreeNode(5);
		
		levelOrderItrative(root);

		for (List<Integer> list : levelOrder(root))
			System.out.println(list);

		List<Integer> list1 = new ArrayList<Integer>();
		listLevelOrderTraversal(root, list1, height(root));
		System.out.println("Only List, still need to work on " + list1);

		System.out.println("inorderTraversal  " + postorderTraversal(root));
	}

	static List<List<Integer>> levelOrder(TreeNode root) {
		List<List<Integer>> tList = new ArrayList<>();
		hasPath(root, tList, 0);
		return tList;
	}

	static void hasPath(TreeNode root, List<List<Integer>> tList, int height) {
		if (root == null)
			return;

		if (height >= tList.size()) {
			tList.add(new LinkedList<Integer>());
		}

		tList.get(height).add(root.val);

		hasPath(root.left, tList, height + 1);
		hasPath(root.right, tList, height + 1);
	}

	static List<List<Integer>> levelOrderItrative(TreeNode root) {
		List<List<Integer>> res = new ArrayList<>();
		Deque<TreeNode> queue = new LinkedList<>();
		queue.addFirst(root);
		while (!queue.isEmpty()) {
			List<Integer> list = new ArrayList<>();
			int n = queue.size();
			for (int i = 0; i < n; i++) {
				TreeNode t = queue.removeLast();
				if (t == null)
					continue;
				list.add(t.val);
				queue.addFirst(t.left);
				queue.addFirst(t.right);
			}
			if (!list.isEmpty())
				res.add(list);
		}
		return res;
	}

	static void printLevelOrder(TreeNode root) {
		Queue<TreeNode> queue = new LinkedList<TreeNode>();
		queue.add(root);
		while (!queue.isEmpty()) {

			TreeNode tempNode = queue.poll();
			System.out.print(tempNode.val + " ");

			if (tempNode.left != null) {
				queue.add(tempNode.left);
			}

			if (tempNode.right != null) {
				queue.add(tempNode.right);
			}
		}
	}

	static void listLevelOrderTraversal(TreeNode root, List<Integer> list, int height) {
		if (root == null)
			return;

		if (height == 1)
			list.add(root.val);
		else if (height > 1) {
			list.add(root.val);
			listLevelOrderTraversal(root.left, list, height - 1);
			listLevelOrderTraversal(root.right, list, height - 1);
		}

	}

	static int height(TreeNode root) {
		if (root == null)
			return 0;

		int l = height(root.left);
		int r = height(root.right);

		return Math.max(l, r) + 1;
	}

	static List<Integer> inorderTraversal(TreeNode root) {
		Stack<TreeNode> stack = new Stack<>();
		List<Integer> ret = new ArrayList<>();
		while (true) {
			while (root != null) {
				stack.push(root);
				root = root.left;
			}
			if (stack.isEmpty()) {
				break; // no node left
			}
			TreeNode node = stack.pop();
			ret.add(node.val);
			root = node.right;
		}
		return ret;
	}

	public List<Integer> preorderTraversal(TreeNode root) {

		List<Integer> ret = new ArrayList<>();
		Stack<TreeNode> stack = new Stack<>();
		stack.push(root);
		while (!stack.isEmpty()) {
			TreeNode node = stack.pop();
			if (node != null) {
				ret.add(node.val);
				stack.push(node.right);
				stack.push(node.left);
			}
		}
		return ret;

	}

	static List<Integer> postorderTraversal(TreeNode root) {

		LinkedList<Integer> ans = new LinkedList<>();
		Stack<TreeNode> stack = new Stack<>();

		if (root == null)
			return ans;

		stack.push(root);
		while (!stack.isEmpty()) {

			TreeNode cur = stack.pop();
			ans.addFirst(cur.val);

			if (cur.left != null) {
				stack.push(cur.left);
			}

			if (cur.right != null) {
				stack.push(cur.right);
			}
		}

		return ans;
	}
}
