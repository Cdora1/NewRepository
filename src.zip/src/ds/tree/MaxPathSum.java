package ds.tree;

public class MaxPathSum {
	int max = Integer.MIN_VALUE;

	public static void main(String[] args) {

		TreeNode root = new TreeNode(1);
		root.left = new TreeNode(2);
		root.right = new TreeNode(3);
		root.left.left = new TreeNode(-4);
		root.left.right = new TreeNode(-5);

		MaxPathSum mps = new MaxPathSum();
		System.out.println("MaxPathSum : " + mps.maxPathSum(root));

	}

	public int maxPathSum(TreeNode root) {
		maxPathSumR(root);
		return max;
	}

	public int maxPathSumR(TreeNode root) {

		if (root == null)
			return 0;
		int left = maxPathSumR(root.left);
		int right = maxPathSumR(root.right);

		int max1 = Math.max(root.val, Math.max(root.val + left, root.val + right));
		max = Math.max(max, Math.max(max1, left + right + root.val));
		return max1;
	}
	static int max(int a, int b) {
		return (a > b) ? a : b;
	}

}
