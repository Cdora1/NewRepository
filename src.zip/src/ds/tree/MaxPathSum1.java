package ds.tree;

public class MaxPathSum1 {

	public static void main(String[] args) {

		TreeNode root = new TreeNode(1);
		root.left = new TreeNode(2);
		root.right = new TreeNode(3);
		root.left.left = new TreeNode(4);
		root.left.right = new TreeNode(5);

		MaxPathSum1 mps = new MaxPathSum1();
		System.out.println("MaxPathSum : " + mps.maxPathSum(root));

	}

	public int maxPathSum(TreeNode root) {
		int max = Integer.MIN_VALUE;
		maxPathSumR(root, max);
		return max;
	}

	public int maxPathSumR(TreeNode root, int res) {

		if (root == null)
			return 0;
		
		int left = maxPathSumR(root.left, res);
		int right = maxPathSumR(root.right, res);

		int temp = max(max(left, right) + root.val, root.val);
		int ans = max(temp, left + right + root.val);
		res = max(res, ans);
		return ans;
	}

	static int max(int a, int b) {
		return (a > b) ? a : b;
	}

}
