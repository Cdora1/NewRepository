package test;

public class Test {

	public static void main(String[] args) {
		System.out.println("This is a debug message");

		int arr[] = { 2, -2, -1, -1, 3, 1, 0, 2, -1, -1, 1, 2, -1, -3, 2 };
		System.out.println(largestSum(arr));

	}

	public static int largestSum(int arr[]) {
		if (arr.length == 0)
			return 0;

		int largestSum = 0, max = 0;
		for (int i : arr) {
			largestSum = largestSum + i;
			if(max < largestSum)
				max = largestSum;
			
			if (largestSum < 0) {
				largestSum = 0;
			}
		}
		return max;
	}

}
