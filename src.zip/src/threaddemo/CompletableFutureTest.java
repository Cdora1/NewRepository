package threaddemo;

import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.function.Supplier;

public class CompletableFutureTest {

	public static void main(String[] args) {

		ExecutorService es = Executors.newFixedThreadPool(10);
		Future<String> ft = es.submit(new Task());
		try {
			System.out.println(ft.get());
		} catch (InterruptedException | ExecutionException e) {
			e.printStackTrace();
		}
		
		CompletableFuture<Integer> future = CompletableFuture.supplyAsync(new Supplier<Integer>() {
			
			public Integer get(){
				return 8;
			}
		});
		
		CompletableFuture<String> future1 = CompletableFuture.supplyAsync(()-> getName()).thenApply(p->firstName(p)).thenApply(p->lastName());
		try {
			System.out.println(future1.get());
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		}
		
		
		// thenAccept() example
		CompletableFuture.supplyAsync(() -> {
			return getName();
		}).thenAccept(product -> {
			System.out.println("Got product detail from remote service " + product);
		});
		
		CompletableFuture.supplyAsync(() -> {
					return getName();
				}).thenApplyAsync(firstname -> {
					return firstName(firstname);
				}, Executors.newCachedThreadPool()).thenAccept(firstname -> System.out.println("My Full Name " + firstname + lastName()));
		
	}
	
	static String getName(){
		return "JayaChandra";
	}
	static String firstName(String firstname){
		return firstname;
	}
	
	static String lastName(){
		return "Dora";
	}
}

class Task implements Callable<String> {
	@Override
	public String call() throws Exception {
		System.out.println("Hello JC");
		return "JC";
	}
}
class T {
	void disp() {
		System.out.println("hiiiiii");
	}
	int add(int a, int b) {
		return a + b;
	}
}

class State<T> {
	T value;
}