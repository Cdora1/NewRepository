package systemdesign.elevetordesign;


public enum ElevatorState {
    UP,
    DOWN,
    STATIONARY,
    MAINTAINANCE
}
