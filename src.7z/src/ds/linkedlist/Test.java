package ds.linkedlist;

public class Test {

	// 1. detected cycle. 2. detected begining of cycle 3. removed the cycle.
	public static void main(String[] args) {

		Node root = new Node(1);
		// root.next = root;

		root.next = new Node(2);
		root.next.next = new Node(3);
		root.next.next.next = new Node(4);
		root.next.next.next = root.next;

		// printList(root);
		System.out.println(hasCircular(root));
		printList(root);

		Node root1 = new Node(1);
		root1.next = new Node(2);
		root1.next.next = new Node(3);
		root1.next.next.next = new Node(4);
		root1.next.next.next.next = new Node(5);
		root1.next.next.next.next.next = new Node(6);

		// Node temp = reverseList(root1);
		// printList(temp);

		reverseBetween(root1, 2, 4);
	}

	/*
	 * 1. First find front node (m) 2. Find tail node (n) 3. Iterate forward from
	 * front node (n-m times), prepending each node to tail and redefiing tail 4.
	 * Attach new tail to front node.
	 */

	static Node reverseBetween(Node head, int m, int n) {
		Node dummy = new Node(-1);
		dummy.next = head;
		Node front = dummy;
		
		for (int i = 1; i < m; i++) {
			front = front.next;
		}
		
		Node tail = front;
		for (int i = m - 1; i <= n; i++) {
			tail = tail.next;
		}
		
		Node stop = tail;
		Node next = front.next;
		
		while (next != stop) {
			Node temp = next.next;
			next.next = tail;
			tail = next;
			next = temp;
		}
		
		front.next = tail;
		return dummy.next;
	}

	static void printList(Node root) {
		if (root == null)
			return;
		Node temp = root;
		while (temp.next != null) {
			System.out.print(temp.item + " ");
			temp = temp.next;
		}
		System.out.println(temp.item);
		System.out.println();
	}

	static boolean hasCircular(Node root) {

		if (root == null)
			return false;

		Node slow = root;
		Node fast = root.next;

		while (fast != null && fast.next != null) {

			int val = 0;
			if (slow.item == fast.item) {
				while (slow != fast) {
					slow = root;
					fast = fast.next;
				}

				val = slow.item;
				while (slow.next != null) {

					if (slow.next.item == val) {
						slow.next = null;
						printList(root);
						return true;
					}
					slow = slow.next;
				}
				return false;
			}
			slow = slow.next;
			fast = fast.next.next;
		}

		return false;
	}

	static Node reverseList(Node head) {
		if (head == null || head.next == null)
			return head;

		Node p1 = head;
		Node p2 = p1.next;

		head.next = null;
		while (p1 != null && p2 != null) {
			Node t = p2.next;
			p2.next = p1;
			p1 = p2;
			p2 = t;
		}

		return p1;
	}

}
