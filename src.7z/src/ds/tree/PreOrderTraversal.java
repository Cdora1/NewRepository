package ds.tree;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Stack;

public class PreOrderTraversal {

	static List<Integer> preOrderTraversal(TreeNode root) {
		Stack<TreeNode> stk = new Stack<>();
		List<Integer> list = new ArrayList<Integer>();
		while (true) {
			while (root != null) {
				list.add(root.val);
				stk.push(root);
				root = root.left;
			}
			TreeNode temp = stk.pop();
			if (temp.right != null) {
				stk.push(temp.right);
				root = temp.right;
			}
			if (stk.isEmpty())
				return list;
		}
	}

	public List<Integer> preorderTraversal(TreeNode root) {

		List<Integer> ret = new ArrayList<>();
		Stack<TreeNode> stack = new Stack<>();
		stack.push(root);
		while (!stack.isEmpty()) {
			TreeNode node = stack.pop();
			if (node != null) {
				ret.add(node.val);
				stack.push(node.right);
				stack.push(node.left);
			}
		}
		return ret;

	}

	static List<Integer> postorderTraversal(TreeNode root) {
		  
	    LinkedList<Integer> ans = new LinkedList<>();
	    Stack<TreeNode> stack = new Stack<>();
		
	    if (root == null) 
	        return ans;
		
		stack.push(root);
	    
		while (!stack.isEmpty()) {
	        
			TreeNode cur = stack.pop();
			ans.addFirst(cur.val);
	        
			if (cur.left != null) {
				stack.push(cur.left);
			}
	        
			if (cur.right != null) {
				stack.push(cur.right);
			} 
		}
	    
		return ans;
	}
	
	public static void main(String[] args) {

		TreeNode root = new TreeNode(1);
		root.left = new TreeNode(2);
		root.right = new TreeNode(3);
		root.left.left = new TreeNode(4);
		root.left.right = new TreeNode(5);
		// root.right.left = new TreeNode(6);
		// root.right.right = new TreeNode(7);
		//System.out.println(preOrderTraversal(root));
		
		System.out.println(postorderTraversal(root));
	}

}
