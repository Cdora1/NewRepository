package sorting;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class OOTBArrayRotate {

	public static void main(String[] args) {
		Integer[] arr = {0,1,2,3,4};
		/*List<Integer> list = Arrays.asList(arr);
		Collections.rotate(list, 2);
		System.out.println(Arrays.toString(arr)); //[3, 4, 0, 1, 2]
*/
		
		int nums[] = {1,2,3,4,5,6,7};
		int k = 3;
		OOTBArrayRotate ar = new OOTBArrayRotate();
		ar.rotate(nums, k);
		
		
	}
	
	public void rotate(int[] nums, int k) {
	    k %= nums.length;
	    reverse(nums, 0, nums.length - 1);
	    reverse(nums, 0, k - 1);
	    reverse(nums, k, nums.length - 1);
	    for(int i=0; i<nums.length;i++){
			System.out.println(nums[i]);
		}
	}

	public void reverse(int[] nums, int start, int end) {
	    while (start < end) {
	        int temp = nums[start];
	        nums[start] = nums[end];
	        nums[end] = temp;
	        start++;
	        end--;
	    }
	}

}
