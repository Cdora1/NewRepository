package dp;

public class MinCostClimbingStairs {

	public static void main(String[] args) {

		int cost[] = { 10, 15, 20 };
		
		//int cost[] = {1, 100, 1, 1, 1, 100, 1, 1, 100, 1};
		// [0, 0, 1, 2, 2, 3, 3, 4, 4, 5, 6] out put dp[];
	//	System.out.println(minCost(cost));
		
		System.out.println("Climb stairs " + minCostClimbingStairs1(cost));
		
	}

	static int minCostClimbingStairs1(int[] cost) {
		int[] dp = new int[cost.length + 1];
		for (int i = 2; i <= cost.length; i++)
			dp[i] = Math.min(dp[i - 1] + cost[i - 1], dp[i - 2] + cost[i - 2]);
		return dp[cost.length];
	}

	static int minCost(int cost[]) {
		for (int i = 2; i < cost.length; i++)
			cost[i] = Math.min(cost[i - 1], cost[i - 2]);

		return Math.min(cost[cost.length - 1], cost[cost.length - 2]);
	}

	public int minCostClimbingStairs(int[] cost) {
		int a = 0, b, min = 0;
		for (int c : cost) {
			b = a;
			a = c + min;
			min = Math.min(a, b);
		}
		return min;
	}
}
