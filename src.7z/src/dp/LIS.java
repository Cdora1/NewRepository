package dp;

import java.util.Arrays;

class LIS {

	static int lengthOfLIS(int[] nums) {
		int[] dp = new int[nums.length];
		int len = 0; // len of sequence

		for (int num : nums) {
			int idx = Arrays.binarySearch(dp, 0, len, num);

			// if not found, return binarySearch return -insertPosition-1
			if (idx < 0)
				idx = -(idx + 1);

			dp[idx] = num;

			// update len when insert position is at the end
			if (idx == len)
				len++;
		}
		return len;
	}

	// Recursive way of solving LIS
	public static void main(String[] args) {
		int A[] = { 2, 5, 3, 7, 11, 8, 10, 13, 6 };
		System.out.println("Length of Longest Increasing Subsequence is " + longestSubsequenceRecursive(A));
		System.out.println("Length of Longest Increasing Subsequence is " + lengthOfLIS(A));
	}

	static int longestSubsequenceRecursive(int arr[]) {
		int maxLen = 0;
		for (int i = 0; i < arr.length - 1; i++) {
			int len = longestSubsequenceRecursive(arr, i + 1, arr[i]);
			if (len > maxLen)
				maxLen = len;
		}
		return maxLen + 1;
	}

	static int longestSubsequenceRecursive(int arr[], int pos, int lastNum) {
		if (pos == arr.length)
			return 0;

		int t1 = 0;
		if (arr[pos] > lastNum)
			t1 = 1 + longestSubsequenceRecursive(arr, pos + 1, arr[pos]);

		int t2 = longestSubsequenceRecursive(arr, pos + 1, lastNum);
		return Math.max(t1, t2);
	}
}
