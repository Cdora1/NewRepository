package dp;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Test {

	public static void main(String[] args) {

		List<String> list1 = Arrays.asList("expect1", "expect2", "expect2", "expect3", "expect3", "expect3", "expect4",
				"expect4", "expect4", "expect4");
		
	    System.out.println(list1.stream().collect(Collectors.groupingBy(k -> k, Collectors.counting())));

	}

}
