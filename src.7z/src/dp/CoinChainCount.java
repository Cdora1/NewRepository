package dp;

import java.util.Arrays;

public class CoinChainCount {

	/*
	 * Input: coins = [1, 2, 5], amount = 11 Output: 3 Explanation: 11 = 5 + 5 + 1
	 */
	public static void main(String[] args) {
		int coins[] = { 1, 2, 5 };
		int amount = 11;

		System.out.println(coinChange(coins, amount));
	}

	static int coinChange(int[] coins, int amount) {
		if (amount == 0)
			return 0;
		int[] dp = new int[amount + 1];
		Arrays.sort(coins);
		coinChangeTopDown(coins, amount, dp);
		return (dp[0] > 0 ? dp[0] : -1);
	}

	static void coinChangeTopDown(int[] coins, int amount, int[] dp) {
		for (int i = coins.length - 1; i >= 0; i--) {
			int reminder = amount - coins[i], lastPlusOne = dp[amount] + 1;
			if (reminder >= 0 && (dp[reminder] == 0 || dp[reminder] > lastPlusOne)) {
				dp[reminder] = lastPlusOne;
				coinChangeTopDown(coins, reminder, dp);
			}
		}
	}
}
