package dp;

public class LongestIncreasingSubsequence {

	public static void main(String[] args) {
		int arr[] = {10,9,2,5,3,7,101,18};
		System.out.println("Longest Increasing Subsequence " + lengthOfLIS(arr));
	}
	static int lengthOfLIS(int[] nums) {
	     if (nums.length <= 1) return nums.length;
	        int max = 0;
	        int[] map = new int[nums.length];
	        for (int i = 0; i < nums.length; i++) {
	            int left = 0;
	            int right = max;
	            while (left < right) {
	                int mid = left + (right - left) / 2;
	                if (map[mid] < nums[i]) {
	                    left = mid + 1;
	                } else {
	                    right = mid;
	                }
	            }
	            map[left] = nums[i];
	            if (left == max) max++;
	        }
	        return max;
	 
	}
}
