package dp;

//TargeTSum same as this problem CountNumberSubsetGivenDifference
// Refer this class CountNumberSubsetGivenDifference
public class TargetSum {

	public static void main(String[] args) {
		int[] nums = { 1, 1, 1, 1, 1 };
		int S = 3;
		System.out.println("findTargetSumWays " + findTargetSumWays(nums, S)); // findTargetSumWays 5

		System.out.println("Target Sum subset_count approach " + findTargetSumWaysApproach2(nums, S));
	}

	static int count1 = 0;

	public static int findTargetSumWays(int[] nums, int target) {
		calculate(nums, 0, 0, target);
		return count1;
	}

	public static void calculate(int[] nums, int i, int sum, int target) {
		if (i == nums.length) {
			if (sum == target)
				count1++;
		} else {
			calculate(nums, i + 1, sum + nums[i], target);
			calculate(nums, i + 1, sum - nums[i], target);
		}
	}
	static int subsetSum(int nums[], int W, int n) {
		int t[][] = new int[n + 1][W + 1];
		t[0][0] = 1;
		for (int i = 1; i <= n; i++) {
			if (nums[i - 1] == 0)
				t[i][0] = 2 * t[i - 1][0];
			else
				t[i][0] = t[i - 1][0];
		}
		for (int i = 1; i <= W; i++) {
			t[0][i] = 0;
		}

		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= W; j++) {
				if (nums[i - 1] <= j) {
					t[i][j] = t[i - 1][j - nums[i - 1]] + t[i - 1][j];
				} else {
					t[i][j] = t[i - 1][j];
				}
			}
		}
		return t[n][W];
	}

	static int findTargetSumWaysApproach2(int[] nums, int S) {
		if (S > 1000)
			return 0;
		
		int n = 0;
		int sum = 0;
		for (int num : nums) {
			sum += num;
			n++;
		}
		int subset = (sum + S);
		if (subset % 2 == 0) {
			subset /= 2;
		} else {
			return 0;
		}
		return subsetSum(nums, subset, n);
	}

}
