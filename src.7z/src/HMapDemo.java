import java.util.HashMap;
import java.util.Map;

public class HMapDemo {

	public static void main(String args[]){
		Map<Integer, String> m =new HashMap<>(5);
		m.put(1, "MAHI");
		m.put(2, "MAHI");
		m.put(3, "MAHI");
		m.put(4, "MAHI");
		m.put(5, "MAHI");
		m.put(6, "MAHI");
		
		m.put(7, "MAHI");
		m.put(8, "MAHI");
		m.put(8, "MAHI");
		m.put(9, "MAHI");
		m.put(10, "MAHI");
		m.put(11, "MAHI");
		
		m.put(12, "MAHI");
		m.put(13, "MAHI");
		
		m.size();
		
		
		m.put(14, "MAHI");
		m.put(15, "MAHI");
		m.put(16, "MAHI");
		m.put(17, "MAHI");
		m.put(18, "MAHI");
		m.put(19, "MAHI");
		
//		m.put(20, "MAHI");
		m.put(21, "MAHI");
		m.put(22, "MAHI");
		m.put(23, "MAHI");
		m.put(24, "MAHI");
		m.put(25, "MAHI");
		
		m.put(26, "MAHI");
		m.put(27, "MAHI");
		
		m.size();
	}
}
