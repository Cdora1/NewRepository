package designpattern;

public class JC {

	/* Java Function to print leaders in an array */
	void printLeaders(int arr[], int size) {
		int max_from_right = arr[size - 1];

		/* Rightmost element is always leader */
		System.out.print(max_from_right + " ");

		for (int i = size - 2; i >= 0; i--) {
			if (max_from_right < arr[i]) {
				max_from_right = arr[i];
				System.out.print(max_from_right + " ");
			}
		}
	}

	static int findPeakUtil(int arr[], int low, int high, int n) {
		// Find index of middle element
		int mid = low + (high - low) / 2; /* (low + high)/2 */

		// Compare middle element with its neighbours (if neighbours
		// exist)
		if ((mid == 0 || arr[mid - 1] <= arr[mid]) && (mid == n - 1 || arr[mid + 1] <= arr[mid]))
			return mid;

		// If middle element is not peak and its left neighbor is
		// greater than it,then left half must have a peak element
		else if (mid > 0 && arr[mid - 1] > arr[mid])
			return findPeakUtil(arr, low, (mid - 1), n);

		// If middle element is not peak and its right neighbor
		// is greater than it, then right half must have a peak
		// element
		else
			return findPeakUtil(arr, (mid + 1), high, n);
	}

	/* Driver program to test above functions */
	public static void main(String[] args) {
		JC lead = new JC();
		int arr[] = new int[] { 16, 17, 4, 3, 5, 2, 1 };
		int n = arr.length;
		lead.dispLeaders(arr, n);

		int arr1[] = { 1, 3, 25, 20, 31, 4, 1, 0, 7 };
		int n1 = arr.length;
		System.out.println(findPeakUtil(arr1, 0, n1 - 1, n1));
	}

	void dispLeaders(int arr[], int n) {

		System.out.println(arr[n-1] + " ");
		int max = arr[n-1];
		for(int i=n-2; i>0; i--){
			if(arr[i]>max){
				System.out.println(arr[i] + " ");
				max = arr[i];
			}
		}
	}
}
