package arrays;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class BiggestNumber {

	public static void main(String[] args) {

		int arr[] = { 54, 546, 548, 60 };
		List<String> arrNumber = new ArrayList<>();
		for (int i : arr) {
			arrNumber.add(Integer.toString(i));
		}

		Collections.sort(arrNumber, new IntCompare());
		for(String str : arrNumber)
			System.out.print(str);
	}

}

class IntCompare implements Comparator<String> {

	@Override
	public int compare(String X, String Y) {
		String XY = X + Y;
		String YX = Y + X;
		return XY.compareTo(YX) > 0 ? -1 : 1;
	}
}