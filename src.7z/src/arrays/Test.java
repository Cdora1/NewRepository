package arrays;

public class Test {

	public static void main(String[] args) {
		
		int arr[] = {2, 2, 0, 4, 0, 8};
		int n = arr.length;
        int count = 0;
        for (int i = 0; i < n; i++)
            if (arr[i] != 0)
                arr[count++] = arr[i]*2;
 
        while (count < n)
            arr[count++] = 0;
        
        for(int k : arr)
        	System.out.print(k + " ");
        
        
        int arr1[] = new int[]{50, 40, 70, 60, 90};
        int index[] = new int[]{3,  0,  4,  1,  2};
        
        int temp[] = new int[arr1.length];
        for(int i=0; i<arr1.length; i++)
        	temp[index[i]] = arr1[i];

        System.out.println();
        for(int i : temp)
        	System.out.print(i + " ");

	}

}
