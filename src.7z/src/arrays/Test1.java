package arrays;

public class Test1 {

	public static void main(String[] args) {

		int arr[] = { 2, 0, 1, 4, 5, 3 };
		int temp[] = new int[arr.length];

		for (int i = 0; i < arr.length; i++) {
			temp[arr[i]] = i;
		}

		/*
		 * for(int i: temp){ System.out.print(i + " "); }
		 */

		int arr1[] = { 1, 2, 3, 4, 5, 6, 7,8,9 };
		int n = arr1.length - 1;
		for (int i = 0; i <= n / 2; i++) {
			if (arr1[n - i] == arr1[i])
				System.out.println(arr[i]);
			else {
				System.out.println(arr1[n - i]);
				System.out.println(arr1[i]);
			}
		}

	}
}
