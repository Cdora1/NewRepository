package arrays;

public class TrailingZeroes {

	public static void main(String[] args) {

		Long fact = fact(30);
		int counter = 0;
		while (fact % 10 == 0) {
			counter++;
			fact = fact / 10;
		}
		System.out.println(counter);
	}

	static Long arr[] = new Long[101];

	static Long fact(int num) {

		if (num == 0 || num == 1)
			return Long.valueOf(1);
		else if (arr[num] != null)
			return arr[num];
		else
			return arr[num] = num * fact(num - 1);
	}

}
