package arrays;

public class TestTT {

	public static void main(String[] args) {

		String path = "https://leetcode.com/problems/simplify-path/";
		for(String st : path.split("/"))
			System.out.print(st + " ");
	}

}
