package graph;

import java.util.Iterator;
import java.util.LinkedList;

public class BFSGraphTest {

	private int V;
	private LinkedList<Integer> adj[];

	BFSGraphTest(int v) {
		this.V = v;
		adj = new LinkedList[v];
		for (int i = 0; i < v; i++)
			adj[i] = new LinkedList<Integer>();
	}

	void addEdge(int v, int w) {
		adj[v].add(w);
	}

	void BFS(int s) {
		// step1 empty visited node list
		boolean visited[] = new boolean[V];

		// step2 Create a Queue BFS
		LinkedList<Integer> queue = new LinkedList<Integer>();

		// mark source node visited
		visited[s] = true;

		// step4 add visited node to linked list
		queue.add(s);

		while (queue.size() != 0) {

			s = queue.poll();
			System.out.println(s + " ");

			Iterator<Integer> itr = adj[s].iterator();
			while (itr.hasNext()) {

				int n = itr.next();
				if (!visited[n]) {
					visited[n] = true;
					queue.add(n);
				}
			}
		}

	}

	public static void main(String[] args) {

		BFSGraphTest gt = new BFSGraphTest(4);
		gt.addEdge(0, 1);
		gt.addEdge(0, 2);
		gt.addEdge(1, 2);
		gt.addEdge(2, 0);
		gt.addEdge(2, 3);
		gt.addEdge(3, 3);

		gt.BFS(0);

	}

}
